/* global QUnit */

sap.ui.require(["gangmaintainance/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
