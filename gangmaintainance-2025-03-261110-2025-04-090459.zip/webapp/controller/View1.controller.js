sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel"
], (Controller, JSONModel) => {
    "use strict";

    return Controller.extend("gangmaintainance.controller.View1", {
        onInit: function () {

            var editableModel = new JSONModel({
                editable: false,
                textvisible: true,
                inputvisible: false// Initially, the table will be non-editable
            });
            this.getView().setModel(editableModel, "edit");

            this.readFun();
        },
        readFun: function () {
            var that = this;
            var sQuery = this.getOwnerComponent().getModel();
            sQuery.read("/gangSet",
                {
                    success: function (odata) {
                        odata.results.forEach(function (data) {

                            data["inputvisible"] = false;
                            data["textvisible"] = true;

                        });
                        var loModel = new JSONModel(odata);
                        that.getView().setModel(loModel, "gang");
                        var oModel = new JSONModel(odata);
                        that.getView().setModel(oModel, "grid");
                    }
                });
        },

        onpress: function (oEvent) {
            var that = this;
            var oContext = oEvent.getSource().getBindingContext("gang");
            var sPath = oContext.getPath().split("/")[2];
            var sTextVisiblePath = "/results/" + sPath + "/textvisible";
            var sInputVisiblePath = "/results/" + sPath + "/inputvisible";

            // Get the model
            var oModel = this.getView().getModel("gang");

            // Update the properties
            oModel.setProperty(sTextVisiblePath, false);
            oModel.setProperty(sInputVisiblePath, true);
        },


onsave: function () {
    var that = this;
    var oModelData = this.getView().getModel("gang").getData();
    var oODataModel = this.getOwnerComponent().getModel();

    // Loop through results and update only those with inputvisible = true
    oModelData.results.forEach(function (item) {
        if (item.inputvisible) {
            var oUpdateData = Object.assign({}, item); // Clone to avoid modifying original
            delete oUpdateData.inputvisible;
            delete oUpdateData.textvisible;

            oODataModel.update("/gangSet('" + item.Gangid + "')", oUpdateData, {
                success: function () {
                    sap.m.MessageToast.show("Gang ID " + item.Gangid + " updated successfully");
                    that.readFun(); // Refresh data
                },
                error: function (err) {
                    sap.m.MessageToast.show("Update failed for Gang ID " + item.Gangid);
                }
            });
        }
    });
}
    

    });
});