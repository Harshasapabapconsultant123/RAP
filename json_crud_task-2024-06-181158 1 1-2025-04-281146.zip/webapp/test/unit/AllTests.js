sap.ui.define([
	"json_crud_task/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
