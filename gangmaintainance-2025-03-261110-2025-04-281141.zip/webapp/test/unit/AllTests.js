sap.ui.define([
	"gangmaintainance/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
